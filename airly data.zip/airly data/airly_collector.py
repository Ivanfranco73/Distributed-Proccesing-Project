#!/usr/bin/env python3
"""
Airly Air Quality Data Collector
Fetches data from Airly API and saves to CSV file.
"""

import requests
import csv
import os
from datetime import datetime
import time
import logging

# Configuration
API_KEY = "LcqB9jmsc8oDRyragDZ9Pw99VnolKsPh"
LATITUDE = 54.3520
LONGITUDE = 18.6466
INSTALLATION_ID = 3387
MAX_DISTANCE_KM = 5
CITY_NAME = "Gdansk"
CSV_FILE = "/data/airly_gdansk.csv"
INTERVAL_SECONDS = 3600  # 1 hour

# Airly API endpoint
API_URL = f"https://airapi.airly.eu/v2/measurements/installation?installationId={INSTALLATION_ID}"

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# CSV headers
CSV_HEADERS = [
    "city", "lat", "lon", "hour", "minute", 
    "PM25", "PM10", "TEMPERATURE", "HUMIDITY", "PRESSURE", "AQI"
]


def fetch_airly_data():
    """Fetch data from Airly API."""
    headers = {
        "apikey": API_KEY
    }
    
    try:
        response = requests.get(API_URL, headers=headers, timeout=30)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        logger.error(f"Failed to fetch data from Airly API: {e}")
        return None


def extract_measurements(data):
    """Extract measurements from API response."""
    if not data:
        return None
    
    cur = {}
    
    # Try current data first
    if data.get("current") and data["current"].get("values"):
        for v in data["current"]["values"]:
            cur[v["name"]] = v["value"]
        
        indexes = data["current"].get("indexes", [])
        cur["aqi"] = indexes[0]["value"] if indexes else ""
    
    # Fall back to history data
    elif data.get("history") and len(data["history"]) > 0:
        h = data["history"][0]
        for v in h.get("values", []):
            cur[v["name"]] = v["value"]
        
        indexes = h.get("indexes", [])
        cur["aqi"] = indexes[0]["value"] if indexes else ""
    
    else:
        logger.warning("No data available in API response")
        return None
    
    return cur


def prepare_csv_row(measurements):
    """Prepare a row for CSV file."""
    now = datetime.now()
    
    return [
        CITY_NAME,
        LATITUDE,
        LONGITUDE,
        now.hour,
        now.minute,
        measurements.get("PM25", ""),
        measurements.get("PM10", ""),
        measurements.get("TEMPERATURE", ""),
        measurements.get("HUMIDITY", ""),
        measurements.get("PRESSURE", ""),
        measurements.get("aqi", "")
    ]


def ensure_csv_headers():
    """Create CSV file with headers if it doesn't exist."""
    os.makedirs(os.path.dirname(CSV_FILE), exist_ok=True)
    
    if not os.path.exists(CSV_FILE):
        with open(CSV_FILE, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(CSV_HEADERS)
        logger.info(f"Created CSV file with headers: {CSV_FILE}")


def save_to_csv(row):
    """Append a row to the CSV file."""
    with open(CSV_FILE, 'a', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(row)
    logger.info(f"Saved data: {row}")


def collect_data():
    """Main function to collect and save data."""
    logger.info("Fetching data from Airly API...")
    
    data = fetch_airly_data()
    if not data:
        return False
    
    measurements = extract_measurements(data)
    if not measurements:
        return False
    
    row = prepare_csv_row(measurements)
    save_to_csv(row)
    
    return True


def main():
    """Main loop - runs data collection every hour."""
    logger.info("Starting Airly Data Collector")
    logger.info(f"Collecting data for {CITY_NAME} (lat: {LATITUDE}, lon: {LONGITUDE})")
    logger.info(f"Data will be saved to: {CSV_FILE}")
    logger.info(f"Collection interval: {INTERVAL_SECONDS} seconds")
    
    ensure_csv_headers()
    
    while True:
        try:
            success = collect_data()
            if success:
                logger.info("Data collection successful")
            else:
                logger.warning("Data collection failed, will retry next interval")
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
        
        logger.info(f"Sleeping for {INTERVAL_SECONDS} seconds...")
        time.sleep(INTERVAL_SECONDS)


if __name__ == "__main__":
    main()
